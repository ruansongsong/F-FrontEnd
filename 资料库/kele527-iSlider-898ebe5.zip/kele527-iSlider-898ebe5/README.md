# iSlider
iSlider 是一个如丝般润滑的高性能H5页面全屏滑动组件, 追求的是性能,简洁,易用.

官网地址: http://kele527.github.io/iSlider/